# StartGemini.ps1 — полный лаунчер для 6 операторов
# - Выбор оператора по номеру (1–6)
# - Чтение ключа из .gemini\keys.json
# - Установка GOOGLE_API_KEY и GEMINI_API_KEY
# - Проверка наличия gemini CLI
# - Логирование START/END в logs\shift.log
# - Форвард своих флагов в gemini через параметр -G
#
# МОДЕЛИ (кратко, по состоянию на 2025-10):
#   gemini-2.5-pro            — максимум качества/рассуждений; длинный контекст; код/анализ.
#   gemini-2.5-flash          — быстрее/дешевле; хороший дефолт для большинства задач.
#   gemini-2.5-flash-lite     — ещё дешевле и быстрее (часто в preview/lite; длинный контекст).
#   gemini-2.5-flash-image    — генерация изображений (актуальная замена image-preview моделей).
#   gemini-2.5-flash-native-audio-preview — нативное аудио I/O (preview; не для прод).
#   gemini-2.0-flash          — прошлое поколение «быстрых» моделей; 1M контекст.
#   gemini-2.0-flash-lite     — прошлое поколение lite.
#   Алиасы: gemini-flash-latest / gemini-pro-latest — «последние» версии соответствующих линеек.
#
# Примечания:
# - Доступные строки моделей и суффиксы (-preview-<MM-YYYY>, -latest, -001) меняются.
# - Preview/experimental версии часто имеют иные лимиты/EOL — проверяйте актуальный список.

[CmdletBinding()]
param(
  [ValidateSet('1','2','3','4','5','6')]
  [string]$N,

  # Модель по умолчанию; можно менять при запуске параметром -Model
  [string]$Model = 'gemini-2.5-flash-lite',

  # Доп. аргументы, которые нужно пробросить напрямую в `gemini` (например: -G '--max_output_tokens','2048','--search','on')
  [string[]]$G
)

function Fail($msg) {
  Write-Host "ERROR: $msg" -ForegroundColor Red
  exit 1
}

# 1) Спросить номер, если не задан
if (-not $N) { $N = Read-Host "Кто сейчас работает? Введите номер 1-6" }

# 2) Прочитать ключи из .gemini\keys.json
$keysPath = Join-Path -Path $PSScriptRoot -ChildPath ".gemini\keys.json"
if (-not (Test-Path $keysPath)) {
  Fail "Файл ключей не найден: $keysPath. Создайте .gemini\\keys.json (номер→ключ) и повторите."
}
try {
  $json = Get-Content -Raw -Path $keysPath | ConvertFrom-Json
} catch {
  Fail "Не удалось прочитать/распарсить $keysPath $($_.Exception.Message)"
}
if (-not $json.PSObject.Properties.Name.Contains($N)) {
  Fail "В $keysPath нет ключа для номера $N."
}
$key = [string]$json.$N
if ([string]::IsNullOrWhiteSpace($key)) { Fail "Пустой ключ для номера $N в $keysPath." }

# 3) Очистить и установить переменные окружения
Remove-Item Env:GOOGLE_API_KEY -ErrorAction SilentlyContinue
Remove-Item Env:GEMINI_API_KEY  -ErrorAction SilentlyContinue
# Если НЕ используете OAuth-вход, можно также очистить проект:
# Remove-Item Env:GOOGLE_CLOUD_PROJECT -ErrorAction SilentlyContinue
$env:GOOGLE_API_KEY = $key
$env:GEMINI_API_KEY  = $key

# 4) Проверить наличие gemini CLI
$gemini = Get-Command gemini -ErrorAction SilentlyContinue
if (-not $gemini) { Fail "Команда 'gemini' не найдена в PATH. Установите Gemini CLI и перезапустите." }

# 5) Подготовить логирование
$logDir  = Join-Path $PSScriptRoot 'logs'
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
$logPath = Join-Path $logDir 'shift.log'
$startAt = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
"[$startAt] START N=$N model=$Model" | Out-File -FilePath $logPath -Append -Encoding utf8

# 6) Запуск gemini с выбранной моделью + ваши флаги (-G)
$exitCode = 0
try {
  if ($G -and $G.Count -gt 0) {
    & gemini -m $Model @G
  } else {
    & gemini -m $Model
  }
  if ($LASTEXITCODE -ne $null) { $exitCode = $LASTEXITCODE }
} catch {
  $exitCode = 1
  Write-Host "Gemini CLI завершился с ошибкой: $($_.Exception.Message)" -ForegroundColor Red
} finally {
  $endAt = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
  "[$endAt] END   N=$N code=$exitCode" | Out-File -FilePath $logPath -Append -Encoding utf8
}

exit $exitCode
