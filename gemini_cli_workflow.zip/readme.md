# Методология командной работы через Gemini CLI (обновлённая)

Эта методология превращает 6 человек в единую команду, где каждый может подхватить задачу с того же контекста, что и предыдущий. Основана на инструментах и командах Gemini CLI.

---

## 1. Цель и принципы

* **Единое мышление** — каждый участник видит те же файлы, историю, цели и план.
* **Непрерывность контекста** — никакие идеи, решения или проблемы не теряются между сменами.
* **Минимум фрикций** — смена занимает не более 2–3 минут.
* **Прозрачность** — все действия фиксируются в PROGRESS.md и журнале смен.
* **Безопасность и автономность** — ключи и данные хранятся только локально, без утечек.

---

## 2. Инфраструктура и структура проекта

```
project/
├── .gemini/
│   ├── keys.json          # локальные ключи операторов (не коммитим)
│   ├── settings.json      # модель, контекст, checkpointing
│   └── commands/
│       ├── continue.toml
│       ├── handoff.toml
│       └── resume.toml
├── logs/shift.log         # автоматический лог смен
├── PROGRESS.md            # журнал проекта
├── CHECKLIST.md           # чек‑лист ритуала смены
└── StartGemini.ps1        # лаунчер выбора оператора
```

---

## 3. Процесс работы

### 3.1 Вход в смену

1. Запустить `StartGemini.ps1` и выбрать номер (1–6).
2. CLI подставит индивидуальный API‑ключ из `.gemini/keys.json`.
3. Выполнить `/resume` — получить краткий бриф (цель, статус, последние действия).
4. Выполнить `/continue` — модель сформирует план шагов на текущую смену.

### 3.2 Работа

* Следовать шагам из `/continue`.
* Все решения и наблюдения кратко записывать в `PROGRESS.md`.
* При значимых изменениях контекста выполнить `/memory refresh`.

### 3.3 Завершение смены

1. Выполнить `/handoff` — модель создаст блок передачи смены.
2. Вставить результат в `PROGRESS.md` (новый блок Shift ...).
3. (Опц.) `/chat save shift-<номер>` — сохранить историю чата.
4. `StartGemini.ps1` автоматически пишет время начала/окончания в `logs/shift.log`.

---

## 4. Форматы файлов

### PROGRESS.md

```markdown
### Shift YYYY‑MM‑DD HH:MM (Operator #N)
- Done:
  - ...
- Next steps:
  - [ ] ...
- Risks/Questions:
  - ...
```

### CHECKLIST.md

```markdown
1. /resume — понять контекст
2. /continue — выстроить план
3. Работать по шагам, фиксировать решения
4. /handoff — оформить передачу смены
5. /memory refresh — обновить знания модели
```

---

## Приложение — команды проекта (.gemini/commands)

**`.gemini/commands/resume.toml`**

```toml
description = "Краткий бриф: цель, статус, последние шаги, ближайшие действия"
prompt = """
Дай сверхкраткий бриф (до 10 строк):
- Главная цель проекта одной строкой.
- Текущая фаза и целевая метрика (если есть).
- 3 последние значимые сделанные вещи (с датами dd.mm).
- 3 ближайших шага (чёткие действия).
- Риски/блокеры (макс. 3).

Контекст:
@{PROGRESS.md}
@{CHECKLIST.md}
"""
```

**`.gemini/commands/continue.toml`**

```toml
description = "Продолжить работу с общего контекста: выстроить план и начать"
prompt = """
Ты подхватываешь работу у предыдущего участника.
Прочитай общий прогресс:
@{PROGRESS.md}

Если после команды переданы аргументы, считай их приоритетами/уточнениями.

Сформируй краткий план (3–7 шагов) и начни с первого, показывая конкретные действия.
В конце выдай блоки:
- Done:
- Next steps (чек-лист):
- Risks/Questions:
"""
```

**`.gemini/commands/handoff.toml`**

```toml
description = "Сформировать чистую передачу смены"
prompt = """
Сформируй отчёт передачи смены. Формат (не менять заголовки):

## Shift Summary
- Operator: <номер/имя>
- Window: <время UTC+03>

## What I did
- Короткие пункты (1 строка каждый)

## Current State
- Состояние ключевых задач (зелёный/жёлтый/красный)

## Open Issues / Risks
- Короткий список блокеров и зависимостей

## Next Steps (handover)
- Чек-лист для следующего оператора

Контекст:
@{PROGRESS.md}
"""
```

**`.gemini/commands/step.toml`**

```toml
description = "Выполнить один шаг и зафиксировать результат"
prompt = """
Тебе передают конкретный шаг работы в тексте после команды.
1) Прочитай контекст:
@{PROGRESS.md}

2) Сформируй конкретный план исполнения шага (микрошаги).
3) Выполни рассуждение и предложи точные действия (команды, изменение файлов, псевдокод/патч).
4) Итог оформи в виде:
- Done: (что сделано, конкретно)
- Artifact(s): (пути/файлы/патчи, если есть)
- Next micro-steps: (2–3 пункта)
- Notes: (краткие наблюдения)

Сохраняй лаконичность, не повторяй PROGRESS.md целиком.
"""
```

**`.gemini/commands/memory_refresh.toml`**

```toml
description = "Подготовить обновление памяти и напомнить выполнить /memory refresh"
prompt = """
Кратко перечисли, какие файлы/секции были изменены в ходе текущей смены (если известно).
Дай 1–2 предложения, почему важно обновить память.
Заверши явной строкой:
NOW RUN: /memory refresh
"""
```

---

## 5. StartGemini.ps1 — полный скрипт (логирование + выбор оператора)

```powershell
# StartGemini.ps1 — полный лаунчер для 6 операторов
# - Выбор оператора по номеру (1–6)
# - Чтение ключа из .gemini\keys.json
# - Установка GOOGLE_API_KEY и GEMINI_API_KEY
# - Проверка наличия gemini CLI
# - Логирование START/END в logs\shift.log

[CmdletBinding()]
param(
  [ValidateSet('1','2','3','4','5','6')]
  [string]$N,
  [string]$Model = 'gemini-2.5-flash-lite'
)

function Fail($msg) {
  Write-Host "ERROR: $msg" -ForegroundColor Red
  exit 1
}

# 1) Спросить номер, если не задан
if (-not $N) { $N = Read-Host "Кто сейчас работает? Введите номер 1-6" }

# 2) Прочитать ключи из .gemini\keys.json
$keysPath = Join-Path -Path $PSScriptRoot -ChildPath ".gemini\keys.json"
if (-not (Test-Path $keysPath)) {
  Fail "Файл ключей не найден: $keysPath. Создайте .gemini\keys.json (номер→ключ) и повторите."
}
try {
  $json = Get-Content -Raw -Path $keysPath | ConvertFrom-Json
} catch {
  Fail "Не удалось прочитать/распарсить $keysPath: $($_.Exception.Message)"
}
if (-not $json.PSObject.Properties.Name.Contains($N)) {
  Fail "В $keysPath нет ключа для номера $N."
}
$key = [string]$json.$N
if ([string]::IsNullOrWhiteSpace($key)) { Fail "Пустой ключ для номера $N в $keysPath." }

# 3) Очистить и установить переменные окружения
Remove-Item Env:GOOGLE_API_KEY -ErrorAction SilentlyContinue
Remove-Item Env:GEMINI_API_KEY  -ErrorAction SilentlyContinue
# Если НЕ используете OAuth-вход в других сценариях, можно также очистить проект:
# Remove-Item Env:GOOGLE_CLOUD_PROJECT -ErrorAction SilentlyContinue
$env:GOOGLE_API_KEY = $key
$env:GEMINI_API_KEY  = $key

# 4) Проверить наличие gemini CLI
$gemini = Get-Command gemini -ErrorAction SilentlyContinue
if (-not $gemini) { Fail "Команда 'gemini' не найдена в PATH. Установите Gemini CLI и перезапустите." }

# 5) Подготовить логирование
$logDir  = Join-Path $PSScriptRoot 'logs'
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
$logPath = Join-Path $logDir 'shift.log'
$startAt = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
"[$startAt] START N=$N model=$Model" | Out-File -FilePath $logPath -Append -Encoding utf8

# 6) Запуск gemini с выбранной моделью
$exitCode = 0
try {
  & gemini -m $Model
  if ($LASTEXITCODE -ne $null) { $exitCode = $LASTEXITCODE }
} catch {
  $exitCode = 1
  Write-Host "Gemini CLI завершился с ошибкой: $($_.Exception.Message)" -ForegroundColor Red
} finally {
  $endAt = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
  "[$endAt] END   N=$N code=$exitCode" | Out-File -FilePath $logPath -Append -Encoding utf8
}

exit $exitCode
```

Это полный, выверенный текст скрипта: он выбирает оператора, подставляет нужный ключ, запускает CLI с указанной моделью и пишет START/END в лог.

---

## 6. Установка и проверка окружения

### Установка Gemini CLI

```powershell
# 1. Установить Node.js >= 18 с https://nodejs.org
# 2. Установить CLI
npm install -g @google/gemini-cli
# или npm install -g @google/gemini-cli
# 3. Проверить
 git --version
# если нет — установить Git for Windows: https://git-scm.com/download/win
git config --global user.name "Your Name"
git config --global user.email "you@example.com"

gemini --version
gemini doctor
```

**Далее обязательно подготовьте ключи (без них CLI не будет работать):**

1. В AI Studio создайте API‑ключ для общего проекта.
2. Заполните файл `.gemini\keys.json` (номер→ключ) — см. раздел выше.
3. Запустите `StartGemini.ps1 -N 1` (или другой номер) — скрипт подставит ключ в окружение.
4. Проверьте доступ к API:

```powershell
# в открывшемся CLI
/version
# или из терминала (вне чата)
 gemini models list
```

Если вывод `gemini doctor` показывает *All checks passed*, всё готово.

### Настройка PowerShell (Windows)

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

---

## 7. .gitignore (для защиты секретов)

```gitignore
.gemini/keys.json
logs/
.env*
```

---

## 8. Подготовка AI Studio / Cloud Project

1. Создай один общий проект в AI Studio.
2. Включи **Generative Language API**.
3. Добавь участников с ролью **API Keys Admin**.
4. Каждый создаёт свой API‑ключ и добавляет его в `.gemini/keys.json`.

---

## 9. Ротация ключей

1. В AI Studio → API Keys → Revoke старый, Create новый.
2. Обновить `.gemini/keys.json`.
3. Перезапустить `StartGemini.ps1`.

---

## 10. Работа с лимитами и ошибками 429

* При превышении лимитов дождаться окна (обычно 60–120 сек) или сменить модель.
* Для тестов используем `gemini-2.5-flash-lite`.
* Для финальных сессий — `gemini-2.5-pro`.

---

## 11. Разрешение конфликтов и обновление контекста

* Работает только **один оператор одновременно**.
* Если нужно передать работу — закрыть `/handoff`, новый участник делает `/resume`.
* После изменений файлов выполнить `/memory refresh`.

---

## 12. Проверочный сценарий (1 мин)

```text
1) powershell -File .\StartGemini.ps1 -N 1
2) /resume  → краткий бриф
3) /continue → план действий
4) /handoff → отчёт смены
5) Проверить logs/shift.log → START/END
```

---

## 13. Итог

Эта методология делает команду синхронной и автономной: каждый оператор продолжает работу предыдущего, не теряя контекст. Все действия фиксируются, смены логируются, а данные защищены локально.
